<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = App\View\Components\CustomerLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('stylesheet'); ?>
        <link href="<?php echo e(asset('css/customer/carousel-kategori.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/customer/scroll-to-top.css')); ?>" rel="stylesheet">
    <?php $__env->stopPush(); ?>

    <!-- hero area -->
    <?php echo $__env->make('layout.customer.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end hero area -->

    <!-- kategori section -->
    <?php echo $__env->make('customer.product.kategori', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end kategori section -->

    <!-- product section -->
    <div id="product-section"></div>
    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $products = $produks->where('kategori_produk_id', $kategori->id);
            $title = $kategori->nama;
        ?>
        <?php if(sizeof($products) != 0): ?>
            <?php if (isset($component)) { $__componentOriginal61ba15efde39a311b2ef4130ac1d3839a18c2eb7 = $component; } ?>
<?php $component = App\View\Components\ProductList::resolve(['title' => $title,'products' => $products] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProductList::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal61ba15efde39a311b2ef4130ac1d3839a18c2eb7)): ?>
<?php $component = $__componentOriginal61ba15efde39a311b2ef4130ac1d3839a18c2eb7; ?>
<?php unset($__componentOriginal61ba15efde39a311b2ef4130ac1d3839a18c2eb7); ?>
<?php endif; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- end product section -->

    <!-- cart section -->
    <?php if(!\Cart::isEmpty()): ?>
        <?php echo $__env->make('customer.cart.floating', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <!-- end cart section -->

    <!-- Scroll to top button -->
    <button class="scroll-to-top-button" id="scroll-to-top-button">
        <i class="fas fa-arrow-up"></i>
    </button>

    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/customer/carousel-kategori.js')); ?>"></script>
        <script src="<?php echo e(asset('js/customer/input-number-counter.js')); ?>"></script>
        <script src="<?php echo e(asset('js/customer/scroll-to-top.js')); ?>"></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/customer/product/index.blade.php ENDPATH**/ ?>