<!DOCTYPE html>
<html lang="en">

<head>

    <title>Namina Resto | Login</title>

    <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo app('Illuminate\Foundation\Vite')([]); ?>

</head>

<body class="bg-gradient-primary">

    <div class="container">

        <?php echo e($slot); ?>


    </div>

    <?php echo $__env->make('template.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>

</html>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/layout/auth.blade.php ENDPATH**/ ?>