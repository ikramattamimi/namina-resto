<div class="row mb-3">
    <label class="col-md-3 col-form-label text-md-end" for="<?php echo e($name); ?>"><?php echo e($label); ?></label>

    <div class="col-md-9">
        <input class="form-control <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="<?php echo e($name); ?>" name="<?php echo e($name); ?>"
            type="<?php echo e($type); ?>" <?php echo e($isRequired); ?> <?php echo e($isDisabled); ?>

            <?php echo e($attributes->class([])->merge(['value' => old($name)])); ?> autocomplete="<?php echo e($name); ?>" autofocus>

        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/components/input.blade.php ENDPATH**/ ?>