<?php if (isset($component)) { $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2 = $component; } ?>
<?php $component = App\View\Components\CustomerLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('customer-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\CustomerLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <!-- hero area -->
    <div style="width:100%; height:100px;">
    </div>
    <!-- end hero area -->

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e($message); ?>

            <button class="close" data-dismiss="alert" type="button" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <?php if($message = Session::get('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e($message); ?>

            <button class="close" data-dismiss="alert" type="button" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- cart -->
    <div class="cart-section my-3">
        <div class="container">
            <div class="col-12 text-center mt-4 mb-5">
                <h3>Orderan Saya</h3>
            </div>

            <?php if (isset($component)) { $__componentOriginal61ba15efde39a311b2ef4130ac1d3839a18c2eb7 = $component; } ?>
<?php $component = App\View\Components\ProductList::resolve(['products' => $cartItems] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product-list'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProductList::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal61ba15efde39a311b2ef4130ac1d3839a18c2eb7)): ?>
<?php $component = $__componentOriginal61ba15efde39a311b2ef4130ac1d3839a18c2eb7; ?>
<?php unset($__componentOriginal61ba15efde39a311b2ef4130ac1d3839a18c2eb7); ?>
<?php endif; ?>

            <div class="row mx-auto my-auto">
                <div class="single-product-item col-12 mb-3 mt-5 rounded-xl">
                    <h4>Total Pesanan</h4>
                    <p class="text">Total Harga &nbsp; : Rp <?php echo e(number_format(Cart::getSubTotal())); ?></p>
                </div>

                <?php echo $__env->make('customer.cart.customer-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <!-- end cart -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2)): ?>
<?php $component = $__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2; ?>
<?php unset($__componentOriginal9bf5f254b2098a37a58c641b2483bb17f45f92d2); ?>
<?php endif; ?>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/customer/cart/index.blade.php ENDPATH**/ ?>