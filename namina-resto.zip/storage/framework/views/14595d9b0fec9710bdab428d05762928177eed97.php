<table class="table table-bordered" id="dataTable" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Nama</th>
            <!-- <th>No Rekening</th> -->
            <th>Saldo</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $rekenings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($rekening->nama); ?></td>
            <!-- <td><?php echo e($rekening->nomor); ?></td> -->
            <td>Rp <?php echo e(number_format($rekening->saldo)); ?></td>
            <td>
                <form onsubmit="return confirm('Apakah Anda Yakin ?');" action="<?php echo e(route('rekening.destroy', $rekening->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <a class="btn btn-circle btn-warning btn-sm" id="editRekening" name="editRekening" href="<?php echo e(route('rekening.edit', $rekening->id)); ?>" role="button">
                        <i class="fas fa-edit"></i>
                    </a>
                    <button class="btn btn-circle btn-danger btn-sm" id="hapusRekening" name="hapusRekening" href="<?php echo e(route('rekening.destroy', $rekening)); ?>" role="button">
                        <i class="fas fa-trash"></i>
                    </button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>Bahan Baku</td>
            <!-- <td> - </td> -->
            <td>Rp <?php echo e(number_format($bahanBaku)); ?></td>
            <td></td>
        </tr>
    </tbody>
</table><?php /**PATH D:\PROJECT\namina-resto\resources\views/rekening/table.blade.php ENDPATH**/ ?>