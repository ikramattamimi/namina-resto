<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve(['headerTitle' => 'Orderan Online Detail'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <div class="card">
            <div class="card-body">
                <div class="container text-dark">
                    <div class="row mb-3">
                        <?php if(isset($pesanan[0])): ?>
                        <div class="col">
                            <h5>
                                <i class="fas fa-globe fa-lg" style="color: #000000;"></i>
                                No. Orderan: <?php echo e($pesanan[0]->kode); ?>

                            </h5>
                        </div>
                        <div class="col">
                            <div class="text-right">
                            
                                <h5>Tanggal: <?php echo e(\Carbon\Carbon::parse($pesanan[0]->created_at)->format('d F Y H:i:s')); ?></h5>
                            
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="row mb-3">
                        <div class="col-sm">
                            <p class="mb-0">Dari</p>
                            <p class="mb-0 font-weight-bold">Namina Group</p>
                            <p class="mb-0">
                                Jl. Raya Garut - Cikajang No.km 14, Sirnagalih, Cisurupan, Kabupaten Garut, Jawa Barat 44163
                            </p>
                            <p class="mb-0">
                                Telp 0262 2543686 / WA 081220088980
                            </p>
                            <p class="mb-0">
                                Tlpn/wa: 02622543686 / 081220088980
                            </p>
                            <p class="mb-0">
                                Email: naminaprivateresto@gmail.com
                            </p>     
                        </div>
                        <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-sm w-25">
                            <p class="mb-0">Pembeli</p>
                            <p class="mb-0 font-weight-bold"><?php echo e($p->nama); ?></p>
                            <p class="mb-0">Tlpn/Wa: <?php echo e($p->no_hp); ?></p>
                            <p class="mb-0"><span class="font-weight-bold">Orderan:</span> Meja No. <?php echo e($p->no_meja); ?></p>
                        </div>
                        <div class="col-sm">
                            <div class="row">
                                <div class="col-sm">
                                    <div class="font-weight-bold">
                                        Status Orderan
                                    </div>
                                    <p><?php echo e($p->nama_status); ?></p>
                                </div>
                                <div class="col-sm">
                                    <div class="font-weight-bold">
                                        Status Dapur
                                    </div>
                                    <p>-</p>  
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="table-responsive">
                <table id="myTable" class="table table-striped mb-4 text-dark">
                    <thead>
                        <tr class="text-center border">
                            <th class="col-sm-1">No.</th>
                            <th class="col-sm-1">Gambar</th>
                            <th class="col-sm-2">Nama Produk</th>
                            <th class="col-sm-1">Harga</th>
                            <th class="col-sm-2">Catatan</th>
                            <th class="col-sm-1">Qty</th>
                            
                            <th class="col-sm-1">Subtotal</th>
                            <th class="col-sm-1">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="border table-bordered">
                        <?php 
                            $counter = 1;
                            $total = 0;
                        ?>
                        <?php $__currentLoopData = $pesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="mb-3">
                            <td><?php echo e($counter); ?></td>
                            <td><img src="/storage/gambar-produk/<?php echo e($data->gambar); ?>" style="width:100px; heigth:100px"></td>
                            <td><?php echo e($data->nama_produk); ?></td>
                            <td><?php echo e($data->harga_jual); ?></td>
                            <td><?php echo e($data->catatan_produk); ?></td>
                            <td><?php echo e($data->qty); ?></td>
                            
                            <td><?php echo e($data->harga_jual * $data->qty); ?></td>
                            <?php
                                $total_akhir = $data->total_bayar;
                                $kode = $data->kode;
                                $catatan = $data->catatan;
                            ?>
                            <td class="text-center d-flex justify-content-center border-bottom-0">
                                    <button class="btn btn-light mr-1 border"><i class="far fa-trash-alt" style="color: #000000;"></i></button>
                            </td>
                        </tr>
                        <?php 
                            $counter++;
                        ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
                <div class="row">
                    <div class="col-md-4 col-lg-6">
                        <div class="border rounded" style="padding: 15px; max-width: 355px;">
                                <h4><b>Catatan Pembeli</b></h4>
                                <p><?php echo e($catatan); ?></p>
                            </div>
                    </div>
                    <div class="col-md-8 col-lg-6">
                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <th style="width:50%; border:none">Pembayaran Diterima:</th>
                                        <td style="border-top: none;border-bottom:1px solid #ddd"><span class="text-dark">Rp </span><input style="border:none" type="number" style="width:150px" name="total" id="total" value="<?php echo e($total_akhir); ?>" readonly></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <a href="/kasir/order/dibayar" class="btn btn-default float-right mr-2 border text-dark">Kembali</a>
                    </div>
                </div>
            <div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <?php echo $__env->make('kasir-order.pending-dan-proses.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH D:\PROJECT\namina-resto\resources\views/kasir-order/dibayar/edit.blade.php ENDPATH**/ ?>