<!DOCTYPE html>
<html lang="en">

<head>

    <!-- title -->
    <title>Namina Resto</title>

    <?php echo $__env->make('layout.customer.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('stylesheet'); ?>

    <?php echo app('Illuminate\Foundation\Vite')([]); ?>

</head>

<body>

    <!--PreLoader-->
    <div class="loader">
        <div class="loader-inner">
            <div class="circle"></div>
        </div>
    </div>
    <!--PreLoader Ends-->

    <!-- header -->
    <?php echo $__env->make('layout.customer.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- end header -->

    <?php echo e($slot); ?>

    <div class="mb-5 pb-5"></div>

    <?php echo $__env->make('layout.customer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('layout.customer.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/layout/customer/index.blade.php ENDPATH**/ ?>