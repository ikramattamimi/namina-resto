<!-- product section -->
<div class="product-section mt-5" id="<?php echo e($title); ?>">
    <div class="container">
        <?php if(isset($title)): ?>
            <h3><?php echo e($title); ?></h3>
        <?php endif; ?>

        <div class="row mx-auto my-auto">
            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $cart = \Cart::get($product->id);
                    $image = $product->gambar ?? $cart->associatedModel->gambar;
                ?>

                <div class=" col-lg-6 col-12 mb-3 rounded-xl px-2">
                    <div class="single-product-item">
                        <div class="row align-items-center justify-content-between">
                            
                            <div class="col-4 mb-3">
                                <img class="rounded img-fluid"
                                    src="<?php echo e(asset('storage/gambar-produk/' . $image)); ?>" />
                                <?php if(($product->is_active ?? true) == false): ?>
                                    <div class="card-img-overlay pt-0">
                                        <span class="badge badge-danger">HABIS</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="col-8">
                                
                                <div class="row mb-2 align-items-center">
                                    <div class="col-9">
                                        <h5 class="card-title text-truncate text-uppercase">
                                            <?php echo e($cart->name ?? $product->nama); ?>

                                        </h5>
                                    </div>
                                    <div class="col-3">
                                        <div class="d-flex justify-content-end">
                                            <?php if(isset($cart)): ?>
                                                <p class="text-danger font-weight-bold text">
                                                    <?php echo e($cart->quantity); ?> x
                                                </p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row align-items-start">
                                    <div class="col-sm-7 col-7">
                                        <p class="mb-2 text">
                                            Rp
                                            <?php echo e(number_format($cart->price ?? $product->harga_jual)); ?>

                                        </p>
                                        <?php if(request()->is('cart')): ?>
                                            <div class="d-flex">
                                                <!-- Button trigger modal -->
                                                <button class="btn p-0" data-toggle="modal"
                                                    data-target="#addProduct-<?php echo e($cart->id); ?>"
                                                    type="button">
                                                    <i class="fas fa-edit text-primary text"></i>
                                                </button>
                                                <form action="<?php echo e(route('cart.remove')); ?>"
                                                    method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input name="id" type="hidden"
                                                        value="<?php echo e($cart->id); ?>">
                                                    <button class="btn btn-lg"
                                                        onclick="confirm('Apakah anda yakin?')">
                                                        <i
                                                            class="fas fa-trash text-danger text"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        <?php endif; ?>

                                    </div>
                                    <?php if(!request()->is('cart')): ?>
                                        <div class="col-sm-5 col-5">
                                            <div
                                                class="d-flex justify-content-end align-items-center">
                                                <!-- Button trigger modal -->

                                                <button class="btn cart-btn"
                                                    <?php if(($product->is_active ?? true) == false): ?> disabled <?php endif; ?>
                                                    data-toggle="modal"
                                                    data-target="#addProduct-<?php echo e($product->id); ?>"
                                                    type="button">
                                                    <i class="fas fa-shopping-cart"></i>Beli
                                                </button>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if(($product->is_active ?? true) == true): ?>
                    <?php if (isset($component)) { $__componentOriginal80340c0a52f56ec515dba89621812788b7ed730e = $component; } ?>
<?php $component = App\View\Components\ProductModal::resolve(['product' => $product] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('product-modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\ProductModal::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal80340c0a52f56ec515dba89621812788b7ed730e)): ?>
<?php $component = $__componentOriginal80340c0a52f56ec515dba89621812788b7ed730e; ?>
<?php unset($__componentOriginal80340c0a52f56ec515dba89621812788b7ed730e); ?>
<?php endif; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<!-- end product section -->
<?php /**PATH D:\PROJECT\namina-resto\resources\views/components/product-list.blade.php ENDPATH**/ ?>