<!-- header -->
<div class="top-header-area rounded-bottom" id="sticker">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-sm-12 text-center">
                <div class="main-menu-wrap">
                    <!-- logo -->
                    <div class="site-logo">
                        <a href="<?php echo e(route('customer.index')); ?>">
                            
                            <img class="img-fluid rounded" src="<?php echo e(asset('img/logo-hitam.png')); ?>" alt="">
                        </a>
                    </div>
                    <!-- logo -->
                </div>
            </div>
        </div>
    </div>
</div>
<!-- end header -->
<?php /**PATH D:\PROJECT\namina-resto\resources\views/layout/customer/topbar.blade.php ENDPATH**/ ?>