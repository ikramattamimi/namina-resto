<div class="d-flex justify-content-center">
    <button type="button" class="btn btn-warning mr-1" title="Edit Status" data-toggle="modal" data-target="#ubahStatus<?php echo e($item->kode); ?>">
        <i class="fas fa-pencil-alt fa-xs"></i>
    </button>
    <a href="/order/pendingDanProses/edit/<?php echo e($item->kode); ?>" class="btn btn-primary mr-1" title="Edit Data">
        <i class="fas fa-edit fa-xs"></i>
    </a>
    <a href="#" class="btn btn-success mr-1" title="Cetak Nota Proses">
        <i class="fas fa-print fa-xs"></i>
    </a>
</div>

<!-- MODALS -->
<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'ubahStatus'.e($item->kode).'','title' => 'Ubah Status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'ubahStatus'.e($item->kode).'','title' => 'Ubah Status']); ?>
    <form action="<?php echo e(route('order.pending-dan-proses.update-status', ['id' => $item->kode])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label for="exampleFormControlTextarea1">Status</label>
        <select class="form-control" id="exampleFormControlSelect1" name="status_id">
           
        </select>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save changes</button>  
    </form>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<!-- END MODALS -->
<?php /**PATH D:\PROJECT\namina-resto\resources\views/order/pending-dan-proses/actions.blade.php ENDPATH**/ ?>