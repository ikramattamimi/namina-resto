<!-- Page level plugins -->
<script src="<?php echo e(asset('template/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('template/js/demo/datatables-demo.js')); ?>"></script>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/bahanBaku/script.blade.php ENDPATH**/ ?>