<?php
    $classes = "btn btn-primary btn-icon-split";
?>

<a <?php echo e($attributes->class([$classes])); ?>>
    <span class="icon text-white-50">
        <i class="fas fa-plus"></i>
    </span>
    <span class="text">Tambah <?php echo e($label); ?></span>
</a>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/components/split-button.blade.php ENDPATH**/ ?>