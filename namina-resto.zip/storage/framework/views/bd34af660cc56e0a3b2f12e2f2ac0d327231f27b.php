
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <div class="d-flex align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                <?php echo e($title); ?>

            </h6>
            <?php if(isset($button)): ?>
                <div class="ml-auto">
                    <?php echo e($button); ?>

                </div>
            <?php endif; ?>
        </div>

    </div>
    <div class="card-body">
        <?php echo e($slot); ?>

    </div>

</div>

<?php /**PATH D:\PROJECT\namina-resto\resources\views/components/card.blade.php ENDPATH**/ ?>