<!-- Page level plugins -->
<script src="<?php echo e(asset('template/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('template/js/demo/datatables-demo.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.29.1/moment.min.js"></script>

<script>
    const totalInput = document.getElementById('total');
    const diskonInput = document.getElementById('diskon');
    const totalAkhirInput = document.getElementById('total-akhir');

    // Fungsi untuk menghitung total akhir
    function updateTotal() {
        const harga = parseFloat(totalInput.value) || 0;
        const diskon = parseFloat(diskonInput.value) || 0;
        const totalAkhir = harga - diskon;

        totalAkhirInput.value = totalAkhir;
    }

    // Tambahkan event listener untuk input diskon
    diskonInput.addEventListener('input', updateTotal);

    // Panggil fungsi pertama kali untuk menginisialisasi nilai total akhir
    updateTotal();
</script>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/order/pending-dan-proses/script.blade.php ENDPATH**/ ?>