<table class="table table-bordered" id="dataTable" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Nama</th>
            <th>No HP</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($pelanggan->nama); ?></td>
                <td><?php echo e($pelanggan->no_hp); ?></td>
                <td>
                    <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                        action="<?php echo e(route('pelanggan.destroy', $pelanggan->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>

                        
                        <a class="btn btn-circle btn-warning btn-sm" id="editPelanggan" name="editPelanggan"
                            href="<?php echo e(route('pelanggan.edit', $pelanggan->id)); ?>" role="button">
                            <i class="fas fa-edit"></i>
                        </a>
                        <button class="btn btn-circle btn-danger btn-sm" id="hapusPelanggan" name="hapusPelanggan"
                            href="<?php echo e(route('pelanggan.destroy', $pelanggan->id)); ?>" role="button">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/pelanggan/table.blade.php ENDPATH**/ ?>