<table class="table table-bordered" id="dataTable" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Gambar</th>
            <th>Nama</th>
            <th>Dapur</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="col-1">
                    <img class="img-fluid rounded mb-3"
                        src="<?php echo e(asset('storage/gambar-kategori/' . $kategori->gambar)); ?>" />
                </td>
                <td class="col-7"><?php echo e($kategori->nama); ?></td>
                <td class="col-2"><?php echo e($kategori->kategori_dapur->nama); ?></td>
                <td class="col-2">
                    <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                        action="<?php echo e(route('kategori.destroy', $kategori->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <a class="btn btn-circle btn-warning btn-sm" id="editProduk" name="editProduk"
                            href="<?php echo e(route('kategori.edit', $kategori->id)); ?>" role="button">
                            <i class="fas fa-edit"></i>
                        </a>
                        <button class="btn btn-circle btn-danger btn-sm" id="hapusProduk" name="hapusProduk"
                            href="<?php echo e(route('kategori.destroy', $kategori->id)); ?>" role="button">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/produk/kategori/table.blade.php ENDPATH**/ ?>