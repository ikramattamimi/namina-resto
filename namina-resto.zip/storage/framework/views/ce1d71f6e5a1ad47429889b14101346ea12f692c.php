<table class="table table-bordered" id="dataTable" cellspacing="0" width="100%">
    <thead>
        <tr>
            <th>Gambar</th>
            <th>Kode Barang</th>
            <th>Nama</th>
            <th>Kategori</th>
            <th>Harga Jual</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $produk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="col-2">
                    <img class="img-fluid rounded mb-3" src="<?php echo e(asset('storage/gambar-produk/' . $produk->gambar)); ?>" />
                </td>
                <td class="col-1"><?php echo e($produk->kode); ?></td>
                <td class="col-3"><?php echo e($produk->nama); ?></td>
                <td class="col-1"><?php echo e($produk->kategori_produk->nama); ?></td>
                <td class="col-2"><?php echo e($produk->harga_jual); ?></td>
                <td class="col-1"><?php echo e($produk->stok); ?></td>
                <td class="col-2">
                    <form onsubmit="return confirm('Apakah Anda Yakin ?');"
                        action="<?php echo e(route('produk.destroy', $produk->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <a class="btn btn-circle btn-warning btn-sm" id="editProduk" name="editProduk"
                            href="<?php echo e(route('produk.edit', $produk->id)); ?>" role="button">
                            <i class="fas fa-edit"></i>
                        </a>
                        <button class="btn btn-circle btn-danger btn-sm" id="hapusProduk" name="hapusProduk"
                            href="<?php echo e(route('produk.destroy', $produk->id)); ?>" role="button">
                            <i class="fas fa-trash"></i>
                        </button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/produk/table.blade.php ENDPATH**/ ?>