<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve(['headerTitle' => 'Data Orderan Online'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php $__env->startPush('stylesheet'); ?>
        <!-- Custom styles for this page -->
        <link href="<?php echo e(asset('template/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
    <?php $__env->stopPush(); ?>

    <div class="text-dark">
        <p>Status Invoice</p>
    </div>
    <?php if (isset($component)) { $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8 = $component; } ?>
<?php $component = App\View\Components\Card::resolve(['title' => 'Data Orderan Online'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\Card::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="table-responsive">
            <table id="dataTable" class="table border table-striped text-dark">
                <thead>
                    <tr>
                        <th style="width:24.1719px">No.</th>
                        <th style="width:69px">No. Order</th>
                        <th style="width:150.5px">Nama</th>
                        <th style="width:78.4375px">Whatsapp</th>
                        <th style="text-align:center; width:171.688px">Orderan</th>
                        <th style="text-align:center; width:44.7188px">Status</th>
                        <th style="text-align:center; width:81.9062px">Status Dapur</th>
                        <th style="text-align:center; width:116.578px">Aksi</th>
                    </tr>
                </thead>
                <tbody class="border table-bordered">
                    <?php
                        $counter = 1;
                    ?>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="mb-3">
                        <td><?php echo e($counter); ?></td>
                        <td><?php echo e($item->kode); ?></td>
                        <td style="max-width: 100px;">
                            <div class="text-truncate">
                                <?php echo e($item->nama); ?>

                            </div>
                        </td>
                        <td><?php echo e($item->no_hp); ?></td>
                        <td class="text-center">
                            <p class="mb-1">Meja No. 14</p>
                            <p class="small mb-1"><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d F Y H:i:s')); ?></p>
                        </td>
                        <td class="text-center text-danger font-weight-bold"><?php echo e($item->nama_status); ?></td>
                        <td class="text-center">-</td>
                        <td class="text-center d-flex justify-content-center border-bottom-0">
                            <button type="button" class="btn btn-warning mr-1" title="Edit Status" data-toggle="modal" data-target="#ubahStatus"><i class="fas fa-pencil-alt fa-xs"></i></button>
                            <a href="/admin/order/invoice/edit/<?php echo e($item->kode); ?>" class="btn btn-primary mr-1" title="Edit Data"><i class="fas fa-search"></i></a>
                        </td>
                    </tr>
                    <?php
                        $counter++;
                    ?>

                    <!-- MODALS -->
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => ['id' => 'ubahStatus','title' => 'Ubah Status']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'ubahStatus','title' => 'Ubah Status']); ?>
                        <form action="<?php echo e(route('order.pending-dan-proses.update-status', ['id' => $item->kode])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="modal-body">
                                <label for="exampleFormControlTextarea1">Status</label>
                                <select class="form-control" id="exampleFormControlSelect1" name="status_id">
                                    <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($s->id); ?>"><?php echo e($s->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary">Save changes</button>  
                            </div>
                        </form>
                          
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                    <!-- END MODALS -->

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8)): ?>
<?php $component = $__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8; ?>
<?php unset($__componentOriginal5f1c24da064cdf37917762bf37a30d0804319ee8); ?>
<?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
        <?php echo $__env->make('order.pending-dan-proses.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>

<?php /**PATH D:\PROJECT\namina-resto\resources\views/order/invoice/index.blade.php ENDPATH**/ ?>