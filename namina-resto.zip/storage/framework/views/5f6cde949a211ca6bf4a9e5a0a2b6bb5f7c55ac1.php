<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve(['headerTitle' => 'Data Orderan Online'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <div class="text-dark">
            <p>Status Dibayar</p>
        </div>
        <div class="card">
            <div class="card-header text-dark">
                <h6>Data Orderan Online</h6>
            </div>
            <div class="card-body">
                <table id="myTable" class="table table-responsive table-striped text-dark">
                    <thead>
                        <tr class="text-center border">
                            <th>No.</th>
                            <th>No. Order</th>
                            <th class="col-sm-3">Nama</th>
                            <th class="col-sm-3">Tanggal</th>
                            <th>Orderan</th>
                            <th>Status</th>
                            <th class="col-sm-1">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="border table-bordered">
                        <tr class="mb-3">
                            <td>1</td>
                            <td>12342</td>
                            <td class="w-15" style="max-width: 100px;">
                                <div class="text-truncate">
                                    Muhammad Irfan Noor Wahid
                                </div>
                            </td>
                            <td>02 September 2023 9:22:57 pm</td>
                            <td>Meja No. 18</td>
                            <td>Dibayar</td>
                            <td class="text-center d-flex justify-content-center border-bottom-0">
                                <button type="button" class="btn btn-primary mr-1"><i class="fas fa-edit fa-xs"></i></button>
                                <button type="button" class="btn btn-success mr-1"><i class="fas fa-print fa-xs"></i></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH D:\PROJECT\namina-resto\resources\views/order/dibayar.blade.php ENDPATH**/ ?>