<div <?php echo e($attributes->merge(['class' => 'col-12'])); ?>>
    <div class="row mb-3 align-items-center">
        <div class="col-lg-3 col-md-4">
            <label><?php echo e($label); ?>

                <?php if($isRequired == 'required'): ?>
                    <span class="text-danger">*</span>
                <?php endif; ?>

            </label>
        </div>
        <div class="col-lg-9 col-md-8">
            <select class="form-control" id="" name="<?php echo e($name); ?>" <?php echo e($isRequired); ?>>
                <?php echo e($slot); ?>

            </select>
        </div>
    </div>
</div>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/components/select.blade.php ENDPATH**/ ?>