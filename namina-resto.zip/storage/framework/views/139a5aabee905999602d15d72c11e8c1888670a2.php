<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve(['headerTitle' => 'Data Orderan Online'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div>
        <div class="text-dark">
            <p>Status Dibatalkan</p>
        </div>
        <div class="card">
            <div class="card-header text-dark">
                <h6>Data Orderan Online</h6>
            </div>
            <div class="card-body">
                <table id="myTable" class="table table-responsive table-striped text-dark">
                    <thead>
                        <tr class="text-center border">
                            <th>No.</th>
                            <th class="col-sm-1">No. Order</th>
                            <th class="col-2">Nama</th>
                            <th>Whatsapp</th>
                            <th scope="col">Orderan</th>
                            <th scope="col">Status</th>
                            <th scope="col">Status Dapur</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody class="border table-bordered">
                        <tr class="mb-3">
                            <td>1</td>
                            <td>12342</td>
                            <td class="w-15" style="max-width: 100px;">
                                <div class="text-truncate">
                                    Muhammad Irfan Noor Wahid
                                </div>
                            </td>
                            <td>0812333455595</td>
                            <td class="text-center">
                                <p class="mb-1">Meja No. 14</p>
                                <p class="small mb-1">02 September 2023 9:22:57 pm</p>
                            </td>
                            <td class="text-center text-danger font-weight-bold">Dibatalkan</td>
                            <td class="text-center">-</td>
                            <td class="text-center d-flex justify-content-center border-bottom-0">
                                <button type="button" class="btn btn-warning mr-1"><i class="fas fa-pencil-alt fa-xs"></i></button>
                                <button type="button" class="btn btn-primary mr-1"><i class="fas fa-search"></i></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?><?php /**PATH D:\PROJECT\namina-resto\resources\views/order/dibatalkan.blade.php ENDPATH**/ ?>