<?php if (isset($component)) { $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040 = $component; } ?>
<?php $component = App\View\Components\AdminLayout::resolve(['headerTitle' => 'Data Orderan Online'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="text-dark">
        <p>Status Pending & Proses</p>
    </div>
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.card','data' => ['title' => 'Data Orderan Online']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Data Orderan Online']); ?>
        <div class="table-responsive">
            <table id="dataTable" class="table border table-striped text-dark">
                <thead>
                    <tr>
                        <th style="width:24.1719px">No.</th>
                        <th style="width:69px">No. Order</th>
                        <th style="width:150.5px">Nama</th>
                        <th style="width:78.4375px">Whatsapp</th>
                        <th style="text-align:center; width:171.688px">Orderan</th>
                        <th style="text-align:center; width:44.7188px">Status</th>
                        <th style="text-align:center; width:81.9062px">Status Dapur</th>
                        <th style="text-align:center; width:116.578px">Aksi</th>
                    </tr>
                </thead>
                <tbody class="border table-bordered">
                    <tr class="mb-3">
                        <td>1</td>
                        <td>12342</td>
                        <td style="max-width: 100px;">
                            <div class="text-truncate">
                                Muhammad Irfan Noor Wahid
                            </div>
                        </td>
                        <td>0812333455595</td>
                        <td class="text-center">
                            <p class="mb-1">Meja No. 14</p>
                            <p class="small mb-1">02 September 2023 9:22:57 pm</p>
                        </td>
                        <td class="text-center text-warning font-weight-bold">Pending</td>
                        <td class="text-center">-</td>
                        <td class="text-center d-flex justify-content-center border-bottom-0">
                            <button type="button" class="btn btn-warning mr-1"><i class="fas fa-pencil-alt fa-xs"></i></button>
                            <button type="button" class="btn btn-primary mr-1"><i class="fas fa-edit fa-xs"></i></button>
                            <button type="button" class="btn btn-success mr-1"><i class="fas fa-print fa-xs"></i></button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <?php $__env->startPush('scripts'); ?>
        <?php echo $__env->make('order.pending-and-proses.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->stopPush(); ?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040)): ?>
<?php $component = $__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040; ?>
<?php unset($__componentOriginalbacdc7ee2ae68d90ee6340a54a5e36f99d0a3040); ?>
<?php endif; ?>

<?php /**PATH D:\PROJECT\namina-resto\resources\views/order/pending-and-proses/index.blade.php ENDPATH**/ ?>