<form action="<?php echo e($action); ?>" method="POST">
    <?php echo method_field($method); ?>
    <?php if($action != ''): ?>
        <?php echo csrf_field(); ?>
    <?php endif; ?>

    <?php echo e($slot); ?>


    <div class="row mb-0">
        <div class="col-md-3"></div>
        <div class="col-md-9">
            <button class="btn btn-primary" type="submit">
                <?php echo e($buttonText); ?>

            </button>
        </div>
    </div>
</form>
<?php /**PATH D:\PROJECT\namina-resto\resources\views/components/form.blade.php ENDPATH**/ ?>