<x-customer-layout>

    <!-- hero area -->
    <div style="background-color: #051922; width:100%; height:100px;">
    </div>
    <!-- end hero area -->

    <div class="col-md-12">
        <div class="detail-contact-info">
            <div class="item-info">
                <i class="fa fa-map-marker item-info-fa" style="color: #1ebea5"></i>
                <p>Alamat</p>
                <p>Garut, Jl. Raya Garut - Cikajang No.km 14, Sirnagalih, Cisurupan, Kabupaten Garut, Jawa Barat 44163
                    Telp 0262 2543686 / WA 081220088980</p>
            </div>
            <div class="item-info">
                <i class="fa fa-whatsapp item-info-fa" style="color: #1ebea5"></i>
                <p>WhatsApp</p>
                <p><a href="https://api.whatsapp.com/send?phone=6281220088980&amp;text=" target="_blank">081220088980</a>
                </p>
            </div>
            <div class="item-info">
                <i class="fa fa-envelope-o item-info-fa" style="color: #1ebea5"></i>
                <p>E-mail</p>
                <p><a href="mailto:naminaprivateresto@gmail.com">naminaprivateresto@gmail.com</a></p>
            </div>
            <div class="item-info">
                <i class="fa fa-clock-o item-info-fa" style="color: #1ebea5"></i>
                <p>Hari &amp; Jam Buka/Tutup</p>
                <p>
                    Hari: Senin-Minggu<br>
                    Jam Buka: 09.00<br>
                    Jam Tutup: 19.00 </p>
            </div>
        </div>
    </div>
</x-customer-layout>
