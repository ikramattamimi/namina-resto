<!DOCTYPE html>
<html lang="en">

<head>

    <title>Namina Resto | Login</title>

    @include('template.head')
    @vite([])

</head>

<body class="bg-gradient-primary">

    <div class="container">

        {{ $slot }}

    </div>

    @include('template.script')

</body>

</html>
