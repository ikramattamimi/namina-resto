

<x-admin-layout headerTitle=" ">
<div class="d-flex justify-content-center align-items-center mt-5">
        <h1>Tidak Ada Pesanan</h1>
</div>   
</x-admin-layout>