<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('pengeluaran_restorans', function (Blueprint $table) {
            $table->bigInteger('id', true);
            $table->bigInteger('rekening_id')->index('fk_rekening_pengeluaran');
            $table->string('nama')->nullable();
            $table->dateTime('tanggal')->nullable();
            $table->decimal('jumlah', 10, 0)->nullable();
            $table->string('nama_admin')->nullable();
            $table->timestamp('created_at')->useCurrent();
            $table->timestamp('updated_at')->useCurrent()->useCurrentOnUpdate();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('pengeluaran_restorans');
    }
};
